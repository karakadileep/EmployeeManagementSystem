package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import com.example.demo.TaxCalculation;

@Entity
@Table(name="Employee_details")
public class Employee 
{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@NotNull
	private int empid;
	
	
	@NotNull
	@Size(min=3, message="First Nameshould have atleast 3 characters")
	private String FirstName;
	
	@NotNull
	@Size(min=3, message="last Nameshould have atleast 3 characters")
	private String LastName;
	
	@NotNull
	@Email
	private String email;
	
	@NotNull
	@Size(min=10, message="Mobile number must have atleast 10 numbers")
	private int PhoneNumber;
	
	@NotNull
	private String dateOfJoining;

	@NotNull
	@Size(min=1, message="Salary number must have atleast 1 number")
	private double salary;
	
	

	private TaxCalculation taxCalculation;

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(int phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	public String getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public TaxCalculation getTaxCalculation() {
		return taxCalculation;
	}

	public void setTaxCalculation(TaxCalculation taxCalculation) {
		this.taxCalculation = taxCalculation;
	}

	

	public Employee(int empid, String firstName, String lastName, String email, int phoneNumber, String dateOfJoining,
			double salary, TaxCalculation taxCalculation) {
		super();
		this.empid = empid;
		FirstName = firstName;
		LastName = lastName;
		this.email = email;
		PhoneNumber = phoneNumber;
		this.dateOfJoining = dateOfJoining;
		this.salary = salary;
		this.taxCalculation = taxCalculation;
	}

	public Employee() {
		super();
	}

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", FirstName=" + FirstName + ", LastName=" + LastName + ", email=" + email
				+ ", PhoneNumber=" + PhoneNumber + ", dateOfJoining=" + dateOfJoining + ", salary=" + salary
				+ ", taxCalculation=" + taxCalculation + "]";
	}
}
