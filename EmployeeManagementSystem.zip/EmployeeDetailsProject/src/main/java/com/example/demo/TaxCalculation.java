package com.example.demo;

public class TaxCalculation 
{

	private double salary;
	private double tax;
	private double totalsal;
	
	public double getSalary() 
	{
		return salary;
	}
	public void setSalary(double salary) 
	{
		this.salary = salary;
	}
	public double getTax() 
	{
		if(salary>250000 || salary<=500000)
		{
			tax=salary *5/100;
		}
		else if(salary>500000 || salary<=1000000)
		{
			tax=salary*10/100;
		}
		else if(salary>1000000)
		{
			tax=salary*20/100;
		}
		else
		{
			tax=0;
		}
		return tax;
	}
	public void setTax(double tax) 
	{
		this.tax = tax;
	}
	public double getTotalsal() 
	{
		totalsal=totalsal-tax;
		return totalsal;
	}
	public void setTotalsal(double totalsal) {
		this.totalsal = totalsal;
	}
	
	
	
	
}
